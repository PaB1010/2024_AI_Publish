package day14;

class  Student{
    // 1. 멤버변수
    private String name;
    private int middleScore;
    private int finalScore;

    // 2. 생성자
    public Student(){};

    public Student(String name , int middleScore , int finalScore){
        this.name=name;
        this.middleScore=middleScore;
        this.finalScore=finalScore;
    }

    // 3. 메소드
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getMiddleScore() {
        return middleScore;
    }

    public void setMiddleScore(int middleScore) {
        this.middleScore = middleScore;
    }

    public int getFinalScore() {
        return finalScore;
    }

    public void setFinalScore(int finalScore) {
        this.finalScore = finalScore;
    }


    @Override
    public String toString() {
        return "Student{" +
                "name='" + name + '\'' +
                ", middleScore=" + middleScore +
                ", finalScore=" + finalScore +
                '}';
    }
}

public class Step3 {
    public static void main(String[] args) {
        /*
        베열 실습1: Student 클래스를 정의하여 최대100명이 저장될 수 있도록 배열 생성 코드 작성하시오.
            조건1 : Student 멤버변수 : 이름 , 중간고사점수 , 기말고사점수
            조건2 : 멤버변수 private , 생성자 2개 이상 , getter and setter , toString 생성
            조건3 : 임의 객체 2개를 생성하여 배열 내 첫번째와 두번째 요소 자리에 저장하시오
            조건4 : 반복문을 이용한 배열을 순회 하시오.
         */

        // 인덱스 : 0~99 , 길이 : 100 , 마지막인덱스 : 99
        Student[] man = new Student[100];
        man[0] = new Student("유재석",100,100);
        man[1] = new Student("강호동",90,90);

        for(int index = 0; index<= man.length-1;index++){
            System.out.println(man[index]);
        }

    }
}
