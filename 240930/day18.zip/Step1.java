package day18;

import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import java.util.Scanner;

public class Step1 {
    public static void main(String[] args) {

        // [1] 문자
        char c1 = 'A';
        System.out.println("c1 = " + c1);
        char c2 = '김';
        System.out.println("c2 = " + c2);

        System.out.println(c1 == 'A');
        System.out.println(c2 == '김');
        System.out.println((int) c1); // 65  -> int는 십진법
        System.out.println((int) c2); // 44608
        // - 문자 타입을 문자열로 만들기 # char 배열을 이용한 문자열 표현 # JAVA:String 클래스
        char[] s3 = new char[3];
        s3[0] = '김';
        s3[1] = '민';
        s3[2] = '재';

        // [2] 문자열
        String s1 = "김민재"; // 리터럴
        String s2 = new String("김민재"); // 객체(리터럴)
        System.out.println(s1 == "김민재"); // true
        System.out.println(s2 == "김민재"); // false
        System.out.println(s2.equals("김민재")); // true. 객체에 포장되어있으면 equals를 사용해서 비교

        // [3] 자바에서 자주 사용되는 문자열 함수들
        // 1. "문자열" .charAT(인덱스) : 지정한 인덱스번호에 위치한 문자 1개 반환 함수
        String 주민등록번호 = "970122-1230123";
        System.out.println(주민등록번호.charAt(7));
        char gender = 주민등록번호.charAt(7);
        if (gender == '1' || gender == '3') {
            System.out.println("남자입니다.");
        } else if (gender == '2' || gender == '4') {
            System.out.println("여자입니다.");
        }
        // [활용] Scanner 클래스에는 nextChar() 메소드가 존재하지 않는다.
        // - Scanner 입력객체에서 문자 1개를 입력받는 방법
        /*
        Scanner scan = new Scanner(System.in);
        char c3 = scan.next().charAt(0); // 키보드로부터 입력받은 문자열 자료중에서 0번째(첫번째)문자 추출
        System.out.println(c3);
        */

        // 2. "문자열".length() # 지정한 문자열의 길이 # 문자개수 반환 함수
        System.out.println(주민등록번호.length()); // 14
        // [활용] 문자열 내 문자 1개씩 추출하기
        for (int index = 0; index < 주민등록번호.length(); index++) {
            System.out.print(" , " + 주민등록번호.charAt(index));
        }

        // 3. "문자열".replace("기존문자" , "새로운문자") # 지정한 문자열 내 기존문자가 존재하면 새로운문자 치환/교체 해서 새로운문자열 반환
        // # 주의할점 : 문자는 항상 불변성의 특징을 따른다.
        String oldStr = "자바 문자열은 불변입니다. 자바문자열은 String 클래스 입니다.";
        oldStr.replace("자바", "JAVA"); // # 지정한 문자열내 "자바"가 있으면 "JAVA"로 치환해서 반환 함수
        System.out.print(oldStr);
        String newStr = oldStr.replace("자바", "JAVA");
        System.out.print(newStr);
        // [활용] 외부로부터 자료를 받았는데 JAVA와 관련된 자료가 포함된 경우 치환
        String htmlStr = "안녕하세요<br/>유재석"; // # html언어의 문법이 포함 # html에서 <br/>는 줄바꿈 뜻
        String newStr2 = htmlStr.replace("<br/>", "\n");
        System.out.println(newStr2);

        // 4. "문자열".subString()
        // "문자열".subString(시작인덱스) : # 시작인덱스 부터 문자열 잘라내서 반환하는 함수
        // "문자열".subString(시작인덱스 , 끝인덱스) : # 시작인덱스 부터 끝인덱스 전(미만)까지 잘라내서 반환하는 함수
        String endNum = 주민등록번호.substring(7);
        System.out.println("endNum = " + endNum);

        String starNum = 주민등록번호.substring(0, 6);
        System.out.println("starNum = " + starNum);

        // 5. "문자열".split(구분문자) # 문자열 내 구분문자가 존재하면 구분문자 기준으로 분해해서 (문자열)배열로 반환
        System.out.println(주민등록번호.split("-")); // 주민등록번호에서 "-" 기준으로 분해한다.
        String[] strArray = 주민등록번호.split("-");
        System.out.println(strArray[0]); // 분해한 문자열배열에서 첫번째 인덱스 값 확인
        System.out.println(strArray[1]);

        // 6. "문자열".indexOf("찾을문자") # 문자열 내 찾을 문자가 존재하면 찾은 문자열이 위치한 인덱스 번호 반환 , 없으면 -1
        String bookName = "이것이 자바 프로그래밍 이다.";
        int findIndex = bookName.indexOf("자바");
        System.out.println("findIndex = " + findIndex);
        int findIndex2 = bookName.indexOf("파이썬");
        System.out.println("findIndex2 = " + findIndex2);

        // 7. "문자열".contains("찾을문자") # 문자열 내 찾을 문자가 존재하면 true 반환 , 없으면 false 반환하는 함수
        boolean findBool = bookName.contains("자바");
        System.out.println("findBool = " + findBool);
        boolean findBool2 = bookName.contains("파이썬");
        System.out.println("findBool2 = " + findBool2);

        // 8. "문자열".getBytes() # 문자열 내 문자 하나씩 바이트로 반환 후 바이트 배열로 반환 함수
        String str = "Hello";
        byte[] bytes = str.getBytes(); // 문자열을 바이트 배열로 변환해서 반환
        System.out.println("Arrays.toString(bytes) = " + Arrays.toString(bytes));

        // 9. new String(바이트배열) # 지정한 바이트 배열을 문자열로 반환 해주는 문자열 클래스 생성자
        String str2 = new String(bytes);
        System.out.println("str2 = " + str2);
    }
}
