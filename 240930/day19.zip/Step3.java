package day19;

import java.util.Scanner;

public class Step3 {
    public static void main(String[] args) {

        try {
            // [1] DB 연동 코드

            // [2] 무한 루프
            while(true){
                System.out.println("1.등록 2.출력 3.수정 4.삭제 : ");
                Scanner scan = new Scanner(System.in);
                int ch = scan.nextInt();

                if(ch==1){
                    // 키보드로부터 입력받은 값을 members 테이블에 저장 하시오.
                }

                if(ch==2){
                    // 현재 members 테이블에 저장된 모든 레코드를 출력 하시오.
                }

                if(ch==3){
                    // 수정할 이름과 새로운 이름 2개를 키보드로부터 입력받아 수정처리 하시오.
                }

                if(ch==4){
                    // 삭제할 이름을 키보드부터 입력받아 삭제처리 하시오.
                }

            }

        }catch (Exception e){
            System.out.println("[예외발생]"+e);
        }
    }
}
