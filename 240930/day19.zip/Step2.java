package day19;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;

public class Step2 {
    public static void main(String[] args) {

        // [1] JDBC(JAVA 와 DB 연동 ) 드라이버(클래스) 로드 # 일반 예외 발생
        try {
            System.out.println(">>JDBC 클래스 로드");
            Class.forName("com.mysql.cj.jdbc.Driver");

            System.out.println(">>DB 접속 시도");
            Connection conn = DriverManager.getConnection(
                    "jdbc:mysql://localhost:3306/java","root","1234");
            System.out.println(">>DB 연동 성공");

            // [2] 자바에서 sql 구문을 실행 하기
            // 1. insert
                // 1. sql 구문 작성
            String sql = "insert into members(name) values('유재석')";
                // 2. sql 구문 실행 # 지정한 sql 구문을 실행하고 응답받기
            conn.prepareStatement(sql).executeUpdate();
            System.out.println("============> 등록 성공");

            // 2. select
                // 1. sql 구문 작성
            String sql2 = "select * from members";
                // 2. sql 구문 실행하고 결과 반환 받기
            ResultSet rs = conn.prepareStatement(sql2).executeQuery();
                // 3. while 반복을 이용한 레코드 하나씩 조회하기
            while (rs.next()) { // rs.next() : rs(select 조회결과 인터페이스)
                // # next() : 조회된 다음 레코드 이동 # 만약 존재하면 true 아니면 false
                String name = rs.getString("name");
                // # rs.getString("속성명"); : 현재 조회중인 레코드/행 에서 지정한 속성명의 값 반환 하는 함수
                System.out.println("name = " + name);
            }

            // 3. update
                // 1. sql 구문 작성 # 만약에 members 테이블에서 name 속성이 '유재석' 이면 '유재석2'로 수정
            String sql3 = "update members set name = '유재석2' where name = '유재석' ";
                // 2. sql 구문 실행
            conn.prepareStatement(sql3).executeUpdate();
            System.out.println("================> 수정 성공");

            // 4. delete
                // 1. sql 구문 작성
            String sql4 = "delete from members where name = '유재석2'";
                // 2. sql 구문 실행
            conn.prepareStatement(sql4).executeUpdate();
            System.out.println("================> 삭제 성공");

        } catch (Exception e){
            System.out.println(">>DB 연동 실패"+e);
        }
    }
}
