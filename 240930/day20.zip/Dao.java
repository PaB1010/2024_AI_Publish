package day20;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.util.HashMap;
import java.util.Map;

public class Dao {

    // * 싱글톤 만들기
    private Dao() {
        DBConnect();
    } //(1)

    private static final Dao dao = new Dao();//(2)

    public static Dao getInstance() { //(3)
        return dao;
    }

    // - JDBC 연동 함수
    private Connection conn; //DB 연동 인터페이스

    public boolean DBConnect() {
        try {
            // 1. JDBC 드라이버 라이브러리 불러오기
            Class.forName("com.mysql.cj.jdbc.Driver");
            // 2. 연동
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/java", "root", "1234");
            System.out.println(">>DB 연동 성공<<");
            return true;
        } catch (Exception e) {
            System.out.println(">>DB 연동 실패" + e);
        }
        return false;
    }

    // 1. 등록 함수
    public boolean create(String phone, String name) {
        // System.out.println("phone = " + phone + ", name = " + name);

        // 1. sql 작성
        String sql = "insert into phonebook(phone , name) values('" + phone + "','" + name + "')";

        // 2. 연동된 인터페이스의 sql 기재 후 실행
        try {
            conn.prepareStatement(sql).executeUpdate();
            return true;
        } catch (Exception e) {
            System.out.println(e);
        }
        return false;
    }

    // 2. 출력 함수
    public Map<String, String> read() {
        // * map 컬렉션 객체 생성 # 여러개의 엔트리(key:value)를 저장하기 위해서
        // 엔트리(phone,name)
        Map<String, String> map = new HashMap<>();
        // 1. sql 작성 # 조회 sql : select * from 테이블명;
        String sql = "select * from phonebook";

        // 2. 연동된 인터페이스의 sql 기재 하고 실행
        try {
            ResultSet rs = conn.prepareStatement(sql).executeQuery();

            // 3. 조회결과 레코드들을 ResultSet 인터페이스를 이용한 레코드 조회
            while (rs.next()) { // 조회된 마지막 레코드까지 하나씩 조회 반복
                // 4. rs.next() : 조회결과에서 다음 레코드로 이동 메소드
                // 다음 레코드가 존재하면 true, 없으면 false
                String phone = rs.getString("phone");
                String name = rs.getString("name");
                // 5. rs.get타입("필드명") : 현재 조회 중인 레코드의 필드 값 반환 함수
                map.put(phone, name);// key:phone , value:name
                // 6. 전화번호를 key에 저장하고 이름을 value에 저장하는 엔트리를 생성하여 map컬렉션에 추가
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return map;// map 컬렉션에 반환
    }
}
