package day20;


import java.util.Map;
import java.util.Scanner;

public class View {

    // * 싱글톤 객체 만들기
    // (1) 생성자를 private으로 한다.
    private View() {
    }

    // (2) 내부 클래스에서 private static final 객체 생성 한다.(싱글톤)
    private static final View view = new View();

    // (3) 내부 클래스 객체를 외부로부터 접근할 수 있는 메소드 선언
    public static View getInstance() {
        return view;
    }

    // 1. 메인페이지(화면) 그리는 함수
    //public static void mainView(){
    public void mainView() {
        while (true) { // 무한루프
            System.out.println("=====메인 화면(전화번호 기록부)=====");
            System.out.println(" 1.create 2.read 3.update 4.delete 5.exit");
            Scanner scan = new Scanner(System.in);
            int choose = scan.nextInt();
            if (choose == 1) {//조건문 : if(조건){}else{}
                System.out.println(">>등록페이지<<");
                System.out.print(">>등록할 전화번호 : ");
                String phone = scan.next();
                System.out.print(">>등록할 성명 : ");
                String name = scan.next();

                boolean result = Controller.getInstance().create(phone, name);
                if (result) {
                    System.out.println("[등록성공]");
                } else {
                    System.out.println("[등록실패]");
                }

            } else if (choose == 2) {
                System.out.println(">>출력페이지<<");
                Map<String ,String > result = Controller.getInstance().read() ; // map 컬렉션은 key 와 vlaue를 한쌍(entry)으로 구성된 구조
                result.keySet().forEach(key->{
                    System.out.println("phone : "+ key +"name : " + result.get(key));
                });

            } else if (choose == 3) {
                System.out.println(">>수정페이지<<");
            } else if (choose == 4) {
                System.out.println(">>삭제페이지<<");
            } else if (choose == 5) {
                break;// 가장 가까운 반목문을 종료한다. continue : 가장 가까운 반목문을 이동한다.
            }

        }
    }
}
